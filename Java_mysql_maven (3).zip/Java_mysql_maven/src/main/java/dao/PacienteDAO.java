package dao;

import model.Paciente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class PacienteDAO {
    

    
    public void cadastrarPaciente(Paciente paciente) throws SQLException {
        String sql = "INSERT INTO paciente (nome, cpf, email, telefone) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getCpf());
            stmt.setString(3, paciente.getEmail());
            stmt.setString(4, paciente.getTelefone());
            stmt.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            if (e.getMessage().contains("cpf")) {
                throw new SQLException("ERRO: CPF já cadastrado no sistema");
            }
            throw e;
        }
    }

    public List<Paciente> listarPacientes() throws SQLException {
        List<Paciente> pacientes = new ArrayList<>();
        String sql = "SELECT * FROM paciente ORDER BY nome";
        
        try (Connection conn = ConexaoBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Paciente p = new Paciente();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setCpf(rs.getString("cpf"));
                p.setEmail(rs.getString("email"));
                p.setTelefone(rs.getString("telefone"));
                pacientes.add(p);
            }
        }
        return pacientes;
    }

    public void atualizarPaciente(Paciente paciente) throws SQLException {
        String sql = "UPDATE paciente SET nome = ?, cpf = ?, email = ?, telefone = ? WHERE id = ?";
        
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getCpf());
            stmt.setString(3, paciente.getEmail());
            stmt.setString(4, paciente.getTelefone());
            stmt.setInt(5, paciente.getId());
            stmt.executeUpdate();
        }
    }

    public void excluirPaciente(int id) throws SQLException {
        String sql = "DELETE FROM paciente WHERE id = ?";
        
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    public Paciente buscarPacientePorId(int id) throws SQLException {
        String sql = "SELECT * FROM paciente WHERE id = ?";
        
        try (Connection conn = ConexaoBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Paciente p = new Paciente();
                    p.setId(rs.getInt("id"));
                    p.setNome(rs.getString("nome"));
                    p.setCpf(rs.getString("cpf"));
                    p.setEmail(rs.getString("email"));
                    p.setTelefone(rs.getString("telefone"));
                    return p;
                }
            }
        }
        return null;
    }
}
