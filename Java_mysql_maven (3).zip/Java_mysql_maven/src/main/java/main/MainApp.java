package main;

import dao.PacienteDAO;
import model.Paciente;
import java.util.List;
import java.util.Scanner;
import java.sql.SQLException;

public class MainApp {

    public static void main(String[] args) {
        PacienteDAO pacienteDAO = new PacienteDAO();

        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n=== SAC - Sistema de Agendamento ===");
                System.out.println("1. Cadastrar novo paciente");
                System.out.println("2. Listar todos os pacientes");
                System.out.println("3. Atualizar paciente");
                System.out.println("4. Excluir paciente");
                System.out.println("5. Sair");
                System.out.print("Escolha uma opção: ");

                String input = scanner.nextLine();
                int opcao;
                try {
                    opcao = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    System.out.println("\nOpção inválida! Digite um número.");
                    continue;
                }

                switch (opcao) {
                    case 1 -> cadastrarPaciente(pacienteDAO, scanner);
                    case 2 -> listarPacientes(pacienteDAO);
                    case 3 -> atualizarPaciente(pacienteDAO, scanner);
                    case 4 -> excluirPaciente(pacienteDAO, scanner);
                    case 5 -> {
                        System.out.println("\nSistema encerrado. Até logo!");
                        return;
                    }
                    default -> System.out.println("\nOpção inválida! Tente novamente.");
                }
            }
        }
    }

    private static void cadastrarPaciente(PacienteDAO dao, Scanner scanner) {
        try {
            Paciente paciente = new Paciente();
            System.out.println("\n--- CADASTRO DE PACIENTE ---");

            System.out.print("Nome completo: ");
            String nome = scanner.nextLine().trim();
            if (nome.isEmpty()) {
                System.out.println("Nome não pode ser vazio.");
                return;
            }
            paciente.setNome(nome);

            System.out.print("CPF (apenas números): ");
            String cpf = scanner.nextLine().trim();
            if (!cpf.matches("\\d{11}")) {
                System.out.println("CPF inválido.");
                return;
            }
            paciente.setCpf(cpf);

            System.out.print("E-mail: ");
            paciente.setEmail(scanner.nextLine().trim());

            System.out.print("Telefone: ");
            paciente.setTelefone(scanner.nextLine().trim());

            dao.cadastrarPaciente(paciente);
            System.out.println("\n✅ Paciente cadastrado com sucesso!");

        } catch (SQLException e) {
            System.out.println("\n⛔ Erro: " + e.getMessage());
        }
    }

    private static void listarPacientes(PacienteDAO dao) {
        try {
            System.out.println("\n--- LISTA DE PACIENTES ---");
            List<Paciente> pacientes = dao.listarPacientes();

            if (pacientes.isEmpty()) {
                System.out.println("Nenhum paciente cadastrado no sistema.");
                return;
            }

            for (Paciente p : pacientes) {
                System.out.println(p);
            }

        } catch (SQLException e) {
            System.out.println("\n⛔ Erro ao acessar banco de dados: " + e.getMessage());
        }
    }

    private static void atualizarPaciente(PacienteDAO dao, Scanner scanner) {
        try {
            System.out.println("\n--- ATUALIZAR PACIENTE ---");
            System.out.print("Informe o ID do paciente: ");
            int id = Integer.parseInt(scanner.nextLine());

            Paciente pacienteExistente = dao.buscarPacientePorId(id);
            if (pacienteExistente == null) {
                System.out.println("\n⛔ Paciente não encontrado!");
                return;
            }

            System.out.println("\nDados atuais:");
            System.out.println(pacienteExistente);
            System.out.println("\nInforme os novos dados (deixe em branco para manter o atual):");

            Paciente pacienteAtualizado = new Paciente();
            pacienteAtualizado.setId(id);

            System.out.print("Nome [" + pacienteExistente.getNome() + "]: ");
            String novoNome = scanner.nextLine();
            pacienteAtualizado.setNome(novoNome.isEmpty() ? pacienteExistente.getNome() : novoNome);

            System.out.print("CPF [" + pacienteExistente.getCpf() + "]: ");
            String novoCpf = scanner.nextLine();
            pacienteAtualizado.setCpf(novoCpf.isEmpty() ? pacienteExistente.getCpf() : novoCpf);

            System.out.print("E-mail [" + pacienteExistente.getEmail() + "]: ");
            String novoEmail = scanner.nextLine();
            pacienteAtualizado.setEmail(novoEmail.isEmpty() ? pacienteExistente.getEmail() : novoEmail);

            System.out.print("Telefone [" + pacienteExistente.getTelefone() + "]: ");
            String novoTelefone = scanner.nextLine();
            pacienteAtualizado.setTelefone(novoTelefone.isEmpty() ? pacienteExistente.getTelefone() : novoTelefone);

            dao.atualizarPaciente(pacienteAtualizado);
            System.out.println("\n✅ Paciente atualizado com sucesso!");

        } catch (Exception e) {
            System.out.println("\n⛔ Erro: " + e.getMessage());
        }
    }

    private static void excluirPaciente(PacienteDAO dao, Scanner scanner) {
        try {
            System.out.println("\n--- EXCLUIR PACIENTE ---");
            System.out.print("Informe o ID do paciente: ");
            int id = Integer.parseInt(scanner.nextLine());

            Paciente paciente = dao.buscarPacientePorId(id);
            if (paciente == null) {
                System.out.println("\n⛔ Paciente não encontrado!");
                return;
            }

            System.out.println("\nDados do paciente:");
            System.out.println(paciente);
            System.out.print("\nTem certeza que deseja excluir? (S/N): ");
            String confirmacao = scanner.nextLine();

            if (confirmacao.equalsIgnoreCase("S")) {
                dao.excluirPaciente(id);
                System.out.println("\n✅ Paciente excluído com sucesso!");
            } else {
                System.out.println("\nOperação cancelada.");
            }

        } catch (Exception e) {
            System.out.println("\n⛔ Erro: " + e.getMessage());
        }
    }
}
